const fsobj = require('fs');
fsobj.readFile('input.txt',function(err,data)
{
    if(err)
    {
        console.log("problem in  reading file");
    }
    else
    {
        console.log('reading the file');
        console.log(data.toString());
    }
});
console.log('Program Ended');



