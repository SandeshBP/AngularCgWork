import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieappComponent } from './component/movieapp/movieapp.component';
import { AddmovieComponent } from './component/addmovie/addmovie.component';
import { SearchmovieComponent } from './component/searchmovie/searchmovie.component';

const routes: Routes = [
  {path:'',component: MovieappComponent},
  {path:'movieapp',component: MovieappComponent},
  {path:'addmovie',component: AddmovieComponent},
  {path:'searchmovie',component: SearchmovieComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
