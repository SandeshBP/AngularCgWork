var express = require('express')
var router=express.Router();
var movies=require('../model/movies')
router.get('/',(req,res)=>{
    console.log('am from router module')
})
//=====================================================add

router.post("/movie",(req,res,next)=>{
    const ipmovie= new movies({
        // _id=req.body.id,
        name:req.body.name,
        rating:req.body.rating,
        dgenre:req.body.dgenre
    });
    console.log(ipmovie)

ipmovie.save((err,movie)=>{
    if(err){
        res.json(err)
        console.log(err)
    }
    else{
        res.json({msg:"inserted"})
        console.log(123)

    }
})
});

//==========================================================get
router.get("/movie/:gener",(req,res,next)=>{
    console.log(req.params.gener)
    movies.find({dgenre:req.params.gener},(err,movie)=>{
        if(err){
            res.json(err)
        }
        else{
            res.json(movie)
            console.log(movie)

        }
    })

});



module.exports=router;