import React, { Component } from 'react';
import axios from 'axios';

class ViewContact extends Component {
    constructor(props) {
        super(props);
    
        this.state = {contact:{
          contactName: "",
          contactNumber: "",},contacts:[]
        };
      }

    
  
    onChangeState=(ctrl,value)=>{
        const {contact}=this.state
        contact[ctrl]=value
        this.setState({contact
        })

      }
      getContacts(){
            axios.get("http://localhost:2000/api/contacts").then(responce=>{
        this.setState({contacts:responce.data})
        }) 
      }
    onSubmit=(e)=>{
        e.preventDefault()
        console.log(this.state.contact)
        axios.post("http://localhost:2000/api/contacts",this.state.contact).then(responce=>{

            })
            this.getContacts()

        
    }
    componentDidMount(){
     this.getContacts()
    }
  render() {
    return (
        <div>
        <h1> Manage Contacts </h1>

        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label className="text text-info"> Contact Name: </label>
            <input
              type="text"
              className="form-control"
              value={this.state.email}
              onChange={(e)=>this.onChangeState('contactName',e.currentTarget.value)}
            />
          </div>
          <div className="form-group">
            <label className="text text-info"> Contact Number: </label>
            <input
              type="text"
              className="form-control"
              value={this.state.password}
              onChange={(e)=>this.onChangeState('contactNumber',e.currentTarget.value)}
            />
          </div>
          <div className="form-group">
            <input type="submit" value="Add Contact" className="btn btn-primary" />
          </div>
        </form>
        <table className="table table-bordered table-stripped">
            <thead >
                <tr>
                    <th>Contact Name</th>
                    <th>Contact Number</th>
                </tr>
            </thead>
            {
                this.state.contacts.map((contact)=><tbody>
                    <tr>
                        <td>{contact.contactName}</td>
                        <td>{contact.contactNumber}</td>

                    </tr>
                </tbody>
                    )
            }
        </table>

      </div>
    );
  }
}

export default ViewContact;
