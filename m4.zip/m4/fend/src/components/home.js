import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <div >
       <p>Home Works</p>
      </div>
    );
  }
}

export default Home;
