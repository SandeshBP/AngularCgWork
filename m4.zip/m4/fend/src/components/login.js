import React, { Component } from 'react';

class Login extends Component {
    constructor(props) {
        super(props);
    
        this.state = {login:{
          email: "",
          password: "",}
        };
      }

    invalidEmail=false
    invalidPsw=false

    onChangeState=(ctrl,value)=>{
      
        const {login}=this.state
        login[ctrl]=value
        this.setState({login
        })

      }
    onSubmit=(e)=>{  
      e.preventDefault()
      this.invalidEmail=false
      this.invalidPsw=false
      
        let email=this.state.login.email;
        let psw=this.state.login.password;
      if(email===""){
        console.log("invalid imail")
        this.invalidEmail=true
      }
       if(psw.length<=4 || psw==" "){
        console.log("invalid ps")

        this.invalidPsw=true

      }
      else if(email=="admin@gmail.com" && psw==12345){
            window.location.replace("/viewContact")
        }
    }

  render() {
    return (
        <div>
        <h1> Login </h1>
        {
              this.invalidEmail ?<p>invalid Email </p>:null
            }
            {this.invalidPsw ?<p>Password is too short</p>:null}

        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label className="text text-info"> Email: </label>
            <input
              type="text"
              className="form-control"
              value={this.state.email}
              onChange={(e)=>this.onChangeState('email',e.currentTarget.value)}
            />
          </div>
          <div className="form-group">
            <label className="text text-info"> Password: </label>
            <input
              type="text"
              className="form-control"
              value={this.state.password}
              onChange={(e)=>this.onChangeState('password',e.currentTarget.value)}
            />
          </div>
          <div className="form-group">
         

            <input type="submit" value="Login" className="btn btn-primary" />
          </div>
        </form>  
      
      </div>
    );
  }
}

export default Login;
