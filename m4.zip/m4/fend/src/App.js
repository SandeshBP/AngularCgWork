import React, { Component } from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Login from './components/login';
import Home from './components/home';
import ViewContact from './components/viewContact';
import NavBar from './components/navBar';

class App extends Component {
  render() {
    return (
      <div >
             <Router>
      <div className="container">
      <NavBar/>
        <h1>Welcome To Manage Contact App</h1>
        <hr/>
        <Switch>
          <Route exact path='/login' component={Login}/>
          <Route exact path='/home' component={Home}/> 
          <Route exact path='/viewContact' component={ViewContact}/>
        </Switch>

      </div>
      </Router>
      </div>
    );
  }
}

export default App;
