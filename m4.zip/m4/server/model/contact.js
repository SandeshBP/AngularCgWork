var mong=require('mongoose');


const contactSchema=new mong.Schema({


    contactName:{
        type:String,
        required:false
    },
    contactNumber:{
        type:Number,    
        required:false
    }
  
});

const contacts=module.exports=mong.model('contacts',contactSchema)