var express = require('express')
var router=express.Router();
var contacts=require('../model/contact')

//=====================================================add

router.post("/contacts",(req,res,next)=>{
    let ipContact=new contacts({
        contactName:req.body.contactName,
        contactNumber:req.body.contactNumber,
        
    });

  ipContact.save((err,data)=>{
    if(err){
        res.send(err)
    }
    else
    res.send('data iserted')
  })
})


//==========================================================get
router.get("/contacts",(req,res,next)=>{

    contacts.find((err,prod)=>{
        if(err){
            res.json(err)
        }
        else{
            res.json(prod)

        }
    })

});



module.exports=router;