var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/product';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        //creating database
        var db = client.db('product');

        //creating  collection
        var collection = db.collection('productscol');

        var products = [
            {
                "proId": 1001,
                "proName": "iPhone",
                "proCost": 76661.1,
                "proDes" :"Electronics"
            },
            {
                "proId": 1002,
                "proName": "MicroMax",
                "proCost": 126661.1,
                "proDes" :"Electronics"
            },
            {
                "proId": 1003,
                "proName": "Coolpad",
                "proCost": 7823,
                "proDes" :"Electronics"
            },
            {
                "proId": 1004,
                "proName": "HTC",
                "proCost": 8876,
                "proDes" :"Electronics"
            },
            {
                "proId": 1005,
                "proName": "LG",
                "proCost": 46661.1,
                "proDes" :"Electronics"
            }
        ]

        //find all mobile
        collection.find().toArray(function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('data is  ', res);
            }
        });
    }
});