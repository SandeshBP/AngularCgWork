import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CousreServeService } from 'src/app/servises/course-serve.service';
@Component({
  selector: 'app-edit',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = false
  constructor(private formbuilder: FormBuilder, private router: Router, private serviceCourse: CousreServeService) { }

  ngOnInit() {
    if (localStorage.getItem("UserName") !== null) {
      let cid = localStorage.getItem("cid")
      if (!cid) {
        alert("invalid action pleaser check user list")
        this.router.navigate(['courseList'])
      }
      else {
        this.editForm = this.formbuilder.group({
          id: [],
          courseName: ['', Validators.required],
          duration: ['', Validators.required],

        })
      }
      this.serviceCourse.getCourseById(+cid).subscribe(data => { this.editForm.setValue(data) })
      console.log(+cid)
    }


  }
  edit() {
    this.submitted = true
    if (this.editForm.invalid) {
      return
    }

    this.serviceCourse.edittojson(this.editForm.value).subscribe(data => { })

    this.router.navigate(['courseList'])
  }


  backToList() {
    this.router.navigate(['courseList'])

  }
}

