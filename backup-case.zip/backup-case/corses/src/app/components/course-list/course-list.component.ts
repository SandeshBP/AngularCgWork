import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CousreServeService } from 'src/app/servises/course-serve.service';
import { Course } from 'src/app/model/course';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {
  constructor(private serviceCourse: CousreServeService,
    private router: Router) { }

  courses: Course[]
  duration: number = 0

  ngOnInit() {
    if (localStorage.getItem("UserName") != null) {
      this.serviceCourse.getCourse().subscribe(data => {
      this.courses = data;
      })
    }
    else {
      this.router.navigate(['login'])
    }
  }


  delete(course: Course) {
    let a = confirm("Do you want delete?")
    if (a) {
      this.serviceCourse.deletetoJson(course.id)
        .subscribe(data => {
          this.courses =
            this.courses.filter(u => { u != course },
              this.ngOnInit())
        })
    }
  }

  addCourse() {
    this.router.navigate(['addCourse'])
  }

  logof() {
    localStorage.removeItem("UserName")
    this.router.navigate(['login'])
  }
  editCourse(cid) {
    localStorage.removeItem("cid")
    localStorage.setItem("cid", cid.id.toString())
    this.router.navigate(['update'])
  }
  
  getDuration(course: string) {
    for (let a of this.courses) {
      if (a.courseName == course) {
        this.duration = a.duration
      }
    }


  }

}
