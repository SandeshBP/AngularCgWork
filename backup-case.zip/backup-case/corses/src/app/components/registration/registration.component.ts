import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CousreServeService } from 'src/app/servises/course-serve.service';
import { User } from 'src/app/model/course';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  regForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  user: User[]
  message: string;
  flag: boolean
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private serviceCourse: CousreServeService) { }

  ngOnInit() {
    this.regForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required]
    })
    this.serviceCourse.getUser().subscribe(data => {this.user = data})

  }
  onSubmit(psw) {
    this.flag = false
    let usrCheck = false
    if (this.regForm.value.password == psw) {
        for (var use of this.user) {
          if (this.regForm.value.email == use.email) {
            alert("user exists ..!\n Please log in")
            usrCheck = true
            break
          }
        }


        if (usrCheck == false) {
          this.serviceCourse.regdataAdd(this.regForm.value)
            .subscribe(data => { alert("Successfully Registered") })
          this.flag = true
        }

      

    }
    else {
      this.message = "Password mismatch..!\nPlease confirm  password"
      console.log(this.message)
    }
  }
}
