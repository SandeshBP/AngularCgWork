import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CousreServeService } from 'src/app/servises/course-serve.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-cource.component.html',
  styleUrls: ['./add-cource.component.css']
})
export class AddCourseComponent implements OnInit {
addForm:FormGroup;
submitted:boolean=false

  

  constructor(private formbuilder:FormBuilder,private router:Router,private serviceCourse:CousreServeService) { }

  ngOnInit() {
    if (localStorage.getItem("UserName")!= null) {
      return

    }
 
    else {
      this.router.navigate(['login'])
    }

    this.addForm=this.formbuilder.group({
id:[],
courseName:['',Validators.required],
duration:['',Validators.required]


    })  
  }

  create(){
    this.submitted=true
if(this.addForm.invalid){
  return
}

    this.serviceCourse.addtoJson(this.addForm.value)
    .subscribe(data=>{alert(this.addForm.value.courseName+" Task added")})
this.router.navigate(['courseList'])
  }

  backToList(){
    this.router.navigate(['courseList'])

  }
}
