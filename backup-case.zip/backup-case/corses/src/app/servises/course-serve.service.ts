import { Injectable } from '@angular/core';

// import { HttpClient } from 'selenium-webdriver/http';
import{HttpClient}from '@angular/common/http'
import { Course, User } from '../model/course';

@Injectable({
  providedIn: 'root'
})
export class CousreServeService {

  baseUrl = "http://localhost:3000/courseList"
  baseUrl1 = "http://localhost:3000/users"

  constructor(private http:HttpClient) { }



  getCourse() {
    return this.http.get<Course[]>(this.baseUrl )
  }

 addtoJson(course) {

    return this.http.post(this.baseUrl,course)

  }

  deletetoJson(id) {
    return this.http.delete(this.baseUrl + "/" + id)
  }

 
  edittojson(course) {
    console.log()
    return this.http.put(this.baseUrl + "/",course )
  }

  getCourseById(id: number) {
    return this.http.get(this.baseUrl + "/" + id)
  }

  regdataAdd(user:User){
    return this.http.post(this.baseUrl1,user)

  }
  getUser(){
    return this.http.get<User[]>(this.baseUrl1)

  }
}








