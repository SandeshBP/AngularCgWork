import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { Course } from 'src/app/model/user';

@Component({
  selector: 'app-json-course',
  templateUrl: './json-course.component.html',
  styleUrls: ['./json-course.component.css']
})
export class JsonCourseComponent implements OnInit {

  constructor( private formbuilder: FormBuilder,
    private router: Router,
    private userservice: UserService) { }

    course: Course[] = [];

  ngOnInit() {
    this.userservice.getCourses().subscribe(data => {
      this.course = data;
      console.log(data);
    });
  }

}
