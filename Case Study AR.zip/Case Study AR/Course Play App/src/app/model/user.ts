export class Course {
  id: number;
  courseName: string;
  courseDuration: string;
  coursePrice: number;
}
