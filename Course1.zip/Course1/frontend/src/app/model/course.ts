export class Course{
    id:number;
    courseName:string;
    duration:number;
    author:string;
    price:number
}
export class User{
    id:number
    firstName:string
    lastName:string
    phoneNumber:number
    email:string
    password:string
}