import { TestBed } from '@angular/core/testing';

import { CourseServeService } from './course-serve.service';

describe('CourseServeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CourseServeService = TestBed.get(CourseServeService);
    expect(service).toBeTruthy();
  });
});
