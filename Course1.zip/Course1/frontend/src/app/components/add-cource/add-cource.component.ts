import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CousreServeService } from 'src/app/servises/course-serve.service';
import { Course } from 'src/app/model/course';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-cource.component.html',
  styleUrls: ['./add-cource.component.css']
})
export class AddCourseComponent implements OnInit {
addForm:FormGroup;
submitted:boolean=false;
course:Course;

  

  constructor(private formbuilder:FormBuilder,private router:Router,private serviceCourse:CousreServeService) { }

  ngOnInit() {
    if (localStorage.getItem("UserName")!= null) {
      
    this.addForm=this.formbuilder.group({
id:[],
courseName:['',Validators.required],
duration:['',Validators.required],
price:['',Validators.required]



    }) 

    }
 
    else {
      this.router.navigate(['login'])
    }
 
  }

  create(){
    this.submitted=true
if(this.addForm.invalid){
  console.log('sss')
  return
}
this.course=this.addForm.value;
this.course.author=localStorage.getItem('UserName')
    this.serviceCourse.addtoJson(this.course)
    .subscribe(data=>{alert(this.addForm.value.courseName+" Task added")})
this.router.navigate(['courseList'])
  }

  backToList(){
    this.router.navigate(['courseList'])

  }
}
