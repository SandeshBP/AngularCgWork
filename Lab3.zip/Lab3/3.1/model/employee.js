var mong=require('mongoose');


const empSchema=new mong.Schema({

    "empId": Number,
    "empName": String,
    "empSalary": Number,
    "empAddress": {
      "city": String,
      "state": String
    }
});

const emps=module.exports=mong.model('emps',empSchema)